this directory contains source code for CMOD.
the sketchbook location in MPIDE is set to this directory.
In libraries directory will be all the libraries created or downloaded
main directory will have the main .pde file