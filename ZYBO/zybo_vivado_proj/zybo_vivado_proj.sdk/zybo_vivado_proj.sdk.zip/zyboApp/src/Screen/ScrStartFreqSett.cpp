/*
 * ScrStartFreqSett.h
 *
 *  Created on: 12.03.2016
 *      Author: Sebi
 */

#include "Screen/ScrStartFreqSett.h"

ScrStartFreqSett::ScrStartFreqSett()
{

}

ScrStartFreqSett::~ScrStartFreqSett()
{

}

void ScrStartFreqSett::sendIncCmd()
{

}

void ScrStartFreqSett::sendDecrCmd()
{

}

void ScrStartFreqSett::sendChScrCmd()
{

}

void ScrStartFreqSett::sendConfirmCmd()
{

}

void ScrStartFreqSett::printData()
{

}
