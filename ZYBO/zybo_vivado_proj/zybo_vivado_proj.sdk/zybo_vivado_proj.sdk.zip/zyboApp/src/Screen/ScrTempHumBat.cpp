/*
 * ScrTempHumBat.h
 *
 *  Created on: 12.03.2016
 *      Author: Sebi
 */
#include "Screen/ScrTempHumBat.h"

ScrTempHumBat::ScrTempHumBat()
{

}

ScrTempHumBat::~ScrTempHumBat()
{

}

void ScrTempHumBat::sendIncCmd()
{

}

void ScrTempHumBat::sendDecrCmd()
{

}

void ScrTempHumBat::sendChScrCmd()
{

}

void ScrTempHumBat::sendConfirmCmd()
{

}

void ScrTempHumBat::printData()
{
	OLED.setCursor(4, 12);
		OLED.putString("temp screen");
		OLED.updateDisplay();
}
