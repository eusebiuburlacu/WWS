/*
 * ScrIncNumSett.h
 *
 *  Created on: 12.03.2016
 *      Author: Sebi
 */

#include "Screen/ScrIncNumSett.h"

ScrIncNumSett::ScrIncNumSett()
{

}

ScrIncNumSett::~ScrIncNumSett()
{

}

void ScrIncNumSett::sendIncCmd()
{

}

void ScrIncNumSett::sendDecrCmd()
{

}

void ScrIncNumSett::sendChScrCmd()
{

}

void ScrIncNumSett::sendConfirmCmd()
{

}

void ScrIncNumSett::printData()
{

}
