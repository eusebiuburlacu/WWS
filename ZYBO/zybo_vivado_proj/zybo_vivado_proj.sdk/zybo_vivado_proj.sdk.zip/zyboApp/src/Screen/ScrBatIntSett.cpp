/*
 * ScrBatIntSett.cpp
 *
 *  Created on: 12.03.2016
 *      Author: Sebi
 */

#include "Screen/ScrBatIntSett.h"

ScrBatIntSett::ScrBatIntSett()
{

}

ScrBatIntSett::~ScrBatIntSett()
{

}

void ScrBatIntSett::sendIncCmd()
{

}

void ScrBatIntSett::sendDecrCmd()
{

}

void ScrBatIntSett::sendChScrCmd()
{

}

void ScrBatIntSett::sendConfirmCmd()
{

}

void ScrBatIntSett::printData()
{

}
