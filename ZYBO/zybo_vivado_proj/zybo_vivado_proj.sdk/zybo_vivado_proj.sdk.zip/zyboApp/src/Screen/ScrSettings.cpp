/*
 * ScrSettings.h
 *
 *  Created on: 12.03.2016
 *      Author: Sebi
 */

#include "Screen/ScrSettings.h"

ScrSettings::ScrSettings()
{

}

ScrSettings::~ScrSettings()
{

}

void ScrSettings::sendIncCmd()
{

}

void ScrSettings::sendDecrCmd()
{

}

void ScrSettings::sendChScrCmd()
{

}

void ScrSettings::sendConfirmCmd()
{

}

void ScrSettings::printData()
{
	OLED.setCursor(4, 12);
		OLED.putString("settings screen");
		OLED.updateDisplay();
}
