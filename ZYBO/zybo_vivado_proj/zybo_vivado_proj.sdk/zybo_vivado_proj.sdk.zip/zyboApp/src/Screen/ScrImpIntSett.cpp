/*
 * ScrImpIntSett.h
 *
 *  Created on: 12.03.2016
 *      Author: Sebi
 */

#include "Screen/ScrImpIntSett.h"

ScrImpIntSett::ScrImpIntSett()
{

}

ScrImpIntSett::~ScrImpIntSett()
{

}

void ScrImpIntSett::sendIncCmd()
{

}

void ScrImpIntSett::sendDecrCmd()
{

}

void ScrImpIntSett::sendChScrCmd()
{

}

void ScrImpIntSett::sendConfirmCmd()
{

}

void ScrImpIntSett::printData()
{

}
