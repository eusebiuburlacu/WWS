#ifndef SD_H
#define SD_H

int initSDCard();

void addSDData(const char* data);


#endif
