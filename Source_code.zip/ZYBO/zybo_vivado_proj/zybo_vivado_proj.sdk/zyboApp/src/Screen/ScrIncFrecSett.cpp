/*
 * ScrIncFrecSett.h
 *
 *  Created on: 12.03.2016
 *      Author: Sebi
 */

#include "Screen/ScrIncFreqSett.h"

ScrIncFreqSett::ScrIncFreqSett()
{

}

ScrIncFreqSett::~ScrIncFreqSett()
{

}

void ScrIncFreqSett::sendIncCmd()
{

}

void ScrIncFreqSett::sendDecrCmd()
{

}

void ScrIncFreqSett::sendChScrCmd()
{

}

void ScrIncFreqSett::sendConfirmCmd()
{

}

void ScrIncFreqSett::printData()
{

}
