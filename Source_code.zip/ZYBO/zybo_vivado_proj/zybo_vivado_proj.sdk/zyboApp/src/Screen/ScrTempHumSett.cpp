/*
 * ScrTempHumSett.h
 *
 *  Created on: 12.03.2016
 *      Author: Sebi
 */
#include "Screen/ScrTempHumSett.h"

ScrTempHumSett::ScrTempHumSett()
{

}

ScrTempHumSett::~ScrTempHumSett()
{

}

void ScrTempHumSett::sendIncCmd()
{

}

void ScrTempHumSett::sendDecrCmd()
{

}

void ScrTempHumSett::sendChScrCmd()
{

}

void ScrTempHumSett::sendConfirmCmd()
{

}

void ScrTempHumSett::printData()
{

}
