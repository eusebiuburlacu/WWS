/*
 * ScrImpIntSett.h
 *
 *  Created on: 12.03.2016
 *      Author: Sebi
 */

#include "Screen/ScrImpIntSett.h"

ScrImpIntSett::ScrImpIntSett()
{

}

ScrImpIntSett::~ScrImpIntSett()
{

}

void ScrImpIntSett::sendIncCmd()
{

}

void ScrImpIntSett::sendDecrCmd()
{

}

void ScrImpIntSett::sendChScrCmd()
{

}

void ScrImpIntSett::sendConfirmCmd()
{

}

void ScrImpIntSett::printData()
{
	OLED.setCursor(0, 1);
	//char data[20];
	//sprintf(data, "imped: %.2f K", impedanceArray[0]);
	OLED.putString("set update Int");

	OLED.updateDisplay();
}
